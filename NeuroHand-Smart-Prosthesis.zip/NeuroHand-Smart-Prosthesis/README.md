# NeuroHand - Smart Prosthesis for People with Amputated Hands

![tests](https://github.com/wajih-dridi/NeuroHand-Smart-Prosthesis/actions/workflows/tests.yml/badge.svg)

![MCU](https://img.shields.io/badge/MCU-ESP32-red) ![Framework](https://img.shields.io/badge/framework-Arduino%20%2F%20PlatformIO-orange) ![Language](https://img.shields.io/badge/language-C%2B%2B-blue) ![3D](https://img.shields.io/badge/mechanics-3D%20printed-lightgrey)

An **EMG-controlled prosthetic hand**. Muscle signals are picked up by surface electrodes, processed on an **ESP32**, and
turned into open/close commands for **five servomotors** that drive a **3D-printed articulated hand**. Five **ACS712**
current sensors monitor every servo to detect blocked fingers (grasped objects or obstacles) and protect the motors.

<p align="center">
  <img src="images/printed_hand_on_forearm.jpg" width="32%" alt="3D-printed NeuroHand on forearm socket">
  <img src="images/printed_hand_open.jpg" width="32%" alt="Printed hand, open">
  <img src="images/printed_hand_closed.jpg" width="32%" alt="Printed hand, closed">
</p>

> **Educational prototype - not a medical device.** Read [`docs/safety.md`](docs/safety.md) before connecting electrodes.

## How it works
```
 Electrodes -> EMG sensor -> ESP32 ADC (1 kHz) -> DC removal -> rectify -> low-pass -> envelope
                                                                              |
                                  calibrated hysteresis threshold + confirmation window
                                                                              |
                                                   open / close command ------+
                                                                              v
   5x ACS712 (current)  -->  stall detection  -->  5x servomotors (slew-rate limited) --> fingers
```

1. **Acquisition:** surface electrodes on the forearm feed an analog EMG sensor board; the ESP32 samples it at 1 kHz.
2. **Processing:** baseline removal, rectification and smoothing give a clean muscle-activity envelope.
3. **Decision:** a guided **auto-calibration** (rest, then flex) sets personal thresholds. A Schmitt trigger with a
   200 ms confirmation window rejects artefacts; a 300 ms hold time prevents chatter.
4. **Actuation:** five servos open/close the fingers with a limited speed.
5. **Protection:** each servo has an ACS712. A sustained over-current freezes the finger (object grasped);
   a hard overload detaches that servo. Inrush current right after a command is ignored.

## Features
- 1 kHz **EMG acquisition** with envelope extraction and **self-calibration** (no hard-coded thresholds)
- **Hysteresis + confirmation window** against false triggers
- **5-finger servo control** with slew-rate limiting and per-finger inversion for mirror-mounted servos
- **Per-servo current sensing (ACS712)** with zero-offset calibration at boot, filtering, soft-stall and hard-overload logic
- Serial tools: recalibrate, live EMG plot, current telemetry, manual open/close override, fault reset
- Signal-processing and stall logic are hardware-independent and **unit-tested on the PC** (run in CI)
- Bench-test sketches in [`examples/`](examples) (raw EMG plotter, servo + ACS712 stall test)

## Technologies
ESP32 - EMG sensor - servomotors - ACS712 current sensors - surface electrodes - Arduino IDE / PlatformIO -
3D printing - CAD design (SolidWorks)

## Hardware
| Part | Role |
|------|------|
| ESP32 DevKit | Signal processing and control |
| EMG sensor board + 3 surface electrodes | Muscle-signal acquisition |
| 5x hobby servomotors | Finger actuation |
| 5x ACS712 (5 A) modules | Per-servo current measurement / stall detection |
| Power: dedicated servo supply + battery supply for the EMG board | See [`docs/hardware.md`](docs/hardware.md) |
| 3D-printed hand and forearm socket | Mechanics (CAD in the images below) |

Default pin map (editable in `include/config.h`):

| Function | ESP32 pins |
|----------|-----------|
| EMG input | GPIO39 (ADC1) |
| Servos (thumb ... little) | GPIO 13, 14, 25, 26, 27 |
| ACS712 outputs (via divider) | GPIO 32, 33, 34, 35, 36 (ADC1) |

<p align="center">
  <img src="images/wiring_diagram.jpg" width="75%" alt="Wiring diagram">
</p>

> **Important:** the ACS712 output swings up to ~5 V and many EMG boards can output above 3.3 V. Both signals
> **must** be limited to 3.3 V before reaching an ESP32 pin. Details in [`docs/hardware.md`](docs/hardware.md).

## Mechanical design
The hand and socket were designed in CAD and 3D printed. The servos are mounted in the palm and pull each finger.

<p align="center">
  <img src="images/cad_render_closed.jpg" width="32%" alt="CAD render, closed hand">
  <img src="images/cad_servo_layout.jpg" width="32%" alt="CAD servo layout inside the palm">
  <img src="images/cad_drawing_sheet.jpg" width="32%" alt="CAD drawing sheet">
</p>

## Development stages
| Stage | What was done |
|-------|---------------|
| 1. Signal acquisition | EMG sensor + electrodes on the forearm, raw signal viewed on the Arduino Serial Plotter |
| 2. Servo protection | Servo + ACS712 current test sketch (stall detection, direction toggling) |
| 3. Mechanics | Hand designed in CAD, 3D printed and assembled |
| 4. Integration | ESP32 firmware controlling 5 servos with 5 current sensors (this repository) |

<p align="center">
  <img src="images/electrode_placement.jpg" width="32%" alt="Electrodes on the forearm">
  <img src="images/prototype_arduino_emg_test.jpg" width="32%" alt="First prototype: Arduino Uno + EMG board">
  <img src="images/emg_serial_plotter.jpg" width="32%" alt="EMG signal on the serial plotter">
</p>

## Repository layout
```
platformio.ini
include/   config.h  emg_processing.h  current_monitor.h
src/       main.cpp                    full firmware
examples/  emg_raw_plotter/  servo_current_test/
tests/     test_emg.cpp  test_current.cpp   host-side verification
docs/      hardware.md  calibration.md  firmware.md  safety.md
images/    photos, CAD renders, wiring diagram
```

## Build & flash
```bash
pip install platformio        # or use the PlatformIO VS Code extension
pio run -t upload
pio device monitor
```
Boot sequence: servo current sensors are zeroed -> stay relaxed ~5 s -> **flex firmly for ~4 s** when prompted ->
EMG control starts. Details: [`docs/calibration.md`](docs/calibration.md). Firmware overview and a map from the
prototype Arduino sketch to this code: [`docs/firmware.md`](docs/firmware.md).

**Serial commands (115200 baud):** `c` recalibrate - `p` EMG plot - `i` current telemetry - `o`/`f`/`a` open/close/auto - `r` reset stall flags

## Run the host tests (no hardware needed)
```bash
make test
```

## Results
Fill this in with your own measurements:

| Metric | Value |
|--------|-------|
| Rest / flex envelope (ADC counts) | _TBD_ |
| Contraction-to-motion latency | _TBD_ (design target ~200-250 ms) |
| Detection accuracy over N trials | _TBD_ |
| Servo current: free motion / blocked finger | _TBD_ |
| Grip test objects | _TBD_ |

## Status
| Item | State |
|------|-------|
| Envelope extraction, detector, stall logic (synthetic-signal host tests) | Done |
| Firmware builds with PlatformIO on your machine | _Your check_ |
| Calibrated on your EMG sensor, thresholds tuned | _Your check_ |
| ACS712 divider fitted, stall thresholds tuned to your servos | _Your check_ |
| Full hand assembled and tested with the final firmware | _Your check_ |

## Author
**Wajih Dridi** - [LinkedIn](https://www.linkedin.com/in/wajih-dridi-804504262/) - [GitHub](https://github.com/wajih-dridi)

## License
MIT - see [LICENSE](LICENSE).
