/**
 * NeuroHand - EMG-controlled prosthetic hand (ESP32, Arduino framework, PlatformIO)
 *
 * Flow:
 *   EMG sensor -> ADC (1 kHz) -> envelope -> calibrated hysteresis threshold -> open/close command
 *   command -> 5 servos (slew-limited)  +  5 ACS712 sensors -> stall detection per finger
 *
 * Stall protection (per finger):
 *   - soft stall  : current stays above STALL_CURRENT_A  -> finger is frozen (object grasped), backs off slightly
 *   - hard overload: current stays above HARD_CURRENT_A  -> that servo is detached (PWM off)
 *   - a new open/close command (or 'r') re-arms the finger
 *
 * Serial commands (115200 baud):
 *   c  re-run EMG calibration          p  toggle EMG plotter output (env, on, off, state)
 *   i  toggle current/state telemetry  o  force open    f  force close    a  automatic EMG control
 *   r  clear stall/fault flags and re-attach servos
 */
#include <Arduino.h>
#include <ESP32Servo.h>
#include "config.h"
#include "emg_processing.h"
#include "current_monitor.h"

// ------------------------------------------------------------------------------------------
// State
// ------------------------------------------------------------------------------------------
enum class Phase { Warmup, CalRest, CalFlex, Run };
enum OverrideMode { AUTO, FORCE_OPEN, FORCE_CLOSE };

struct Finger {
    Servo              servo;
    bool               attached = false;
    bool               latched  = false;    // stall already handled for the current command
    float              angle    = OPEN_ANGLE;
    float              target   = OPEN_ANGLE;
    float              amps     = 0.0f;
    cur::Acs712        acs;
    cur::StallDetector stall;
};

static Finger hand[NUM_FINGERS];

static emg::Envelope envelope;
static emg::Detector detector;

static Phase        phase = Phase::Warmup;
static OverrideMode ovrMode = AUTO;
static uint32_t phaseStartMs = 0;
static uint32_t nextSampleUs = 0;
static uint32_t lastServoMs  = 0;
static uint32_t lastPlotMs   = 0;
static uint32_t lastCurMs    = 0;

static float    restSum = 0, flexSum = 0;
static uint32_t restN = 0, flexN = 0;
static float    restLevel = 0, flexLevel = 0;

static bool plotOutput = false;
static bool curOutput  = false;
static bool lastCmdClosed = false;

// ------------------------------------------------------------------------------------------
// Servo helpers
// ------------------------------------------------------------------------------------------
static inline float physicalAngle(int i, float logical)
{
    return FINGER_INVERT[i] ? (float)(OPEN_ANGLE + CLOSED_ANGLE) - logical : logical;
}

static void attachFinger(int i)
{
    Finger& f = hand[i];
    if (f.attached) return;
    f.servo.setPeriodHertz(50);
    f.servo.attach(FINGER_PINS[i], SERVO_MIN_US, SERVO_MAX_US);
    f.servo.write((int)physicalAngle(i, f.angle));
    f.attached = true;
}

static void detachFinger(int i)
{
    Finger& f = hand[i];
    if (!f.attached) return;
    f.servo.detach();
    f.attached = false;
}

/** Issue a new open/close command to all fingers (clears stall/fault state). */
static void setCommand(bool closed, uint32_t nowMs)
{
    lastCmdClosed = closed;
    for (int i = 0; i < NUM_FINGERS; i++) {
        Finger& f = hand[i];
        f.stall.onCommand(nowMs);
        f.latched = false;
        f.target = closed ? CLOSED_ANGLE : OPEN_ANGLE;
        attachFinger(i);
    }
}

static void setupCurrentSensors()
{
    // Measure each sensor's zero-current voltage BEFORE the servos are attached (servo supply must be on).
    for (int i = 0; i < NUM_FINGERS; i++) {
        analogSetPinAttenuation(ACS_PINS[i], ADC_11db);
        float sum = 0;
        for (int k = 0; k < 200; k++) { sum += analogReadMilliVolts(ACS_PINS[i]); delay(1); }
        const float avgMv = sum / 200.0f;

        Finger& f = hand[i];
        f.acs.sensitivityVperA = ACS_SENSITIVITY_V_A;
        f.acs.dividerRatio     = ACS_DIVIDER_RATIO;
        f.acs.alpha            = ACS_FILTER_ALPHA;
        f.acs.calibrateZero(avgMv);

        f.stall.stallA    = STALL_CURRENT_A;
        f.stall.hardA     = HARD_CURRENT_A;
        f.stall.confirmMs = STALL_CONFIRM_MS;
        f.stall.hardMs    = HARD_CONFIRM_MS;
        f.stall.inrushMs  = INRUSH_IGNORE_MS;

        Serial.printf("[acs] finger %d: pin=%.0f mV, zero=%.3f V%s\n", i, avgMv, f.acs.zeroV,
                      (f.acs.zeroV < 2.2f || f.acs.zeroV > 2.8f) ? "  <-- WARNING: expected ~2.5 V, check wiring/divider/5V supply" : "");
    }
}

// ------------------------------------------------------------------------------------------
// Servo + current update (every SERVO_UPDATE_MS)
// ------------------------------------------------------------------------------------------
static void servoTick(uint32_t nowMs)
{
    for (int i = 0; i < NUM_FINGERS; i++) {
        Finger& f = hand[i];
        f.amps = f.acs.update((float)analogReadMilliVolts(ACS_PINS[i]));
        if (!f.attached) continue;                                    // detached after a hard fault

        const cur::State st = f.stall.update(f.amps, nowMs);

        if (st == cur::State::Fault) {
            detachFinger(i);
            Serial.printf("[stall] finger %d OVERLOAD (%.2f A) -> servo detached. Send 'r' or change command to re-arm.\n", i, f.amps);
            continue;
        }

        if (st == cur::State::Holding) {
            if (!f.latched) {                                         // object grasped / blocked: freeze and relax a little
                f.latched = true;
                const float dir = ((CLOSED_ANGLE > OPEN_ANGLE) ? 1.0f : -1.0f) * (lastCmdClosed ? 1.0f : -1.0f);
                f.angle -= dir * STALL_BACKOFF_DEG;
                f.target = f.angle;
                Serial.printf("[stall] finger %d blocked (%.2f A) -> holding at %.0f deg\n", i, f.amps, f.angle);
            }
        } else if (f.angle < f.target) {
            f.angle = fminf(f.angle + SERVO_STEP_DEG, f.target);
        } else if (f.angle > f.target) {
            f.angle = fmaxf(f.angle - SERVO_STEP_DEG, f.target);
        }
        f.servo.write((int)physicalAngle(i, f.angle));
    }
}

// ------------------------------------------------------------------------------------------
// EMG calibration state machine
// ------------------------------------------------------------------------------------------
static void startPhase(Phase p)
{
    phase = p;
    phaseStartMs = millis();
    restSum = flexSum = 0; restN = flexN = 0;
    switch (p) {
        case Phase::Warmup:  Serial.println(F("[cal] warming up - stay relaxed...")); break;
        case Phase::CalRest: Serial.println(F("[cal] RELAX the muscle (measuring rest level)")); break;
        case Phase::CalFlex: Serial.println(F("[cal] FLEX firmly and hold (measuring contraction level)")); break;
        case Phase::Run:     break;
    }
}

static void finishCalibration()
{
    restLevel = restN ? restSum / restN : 0;
    flexLevel = flexN ? flexSum / flexN : 0;
    const float span = flexLevel - restLevel;

    Serial.printf("[cal] rest=%.1f  flex=%.1f  span=%.1f counts\n", restLevel, flexLevel, span);
    if (span < CAL_MIN_SEPARATION) {
        Serial.println(F("[cal] FAILED: contraction not distinguishable from rest. Check electrodes/gain. Retrying..."));
        startPhase(Phase::CalRest);
        return;
    }
    detector.confirmMs = CONFIRM_MS;
    detector.minHoldMs = MIN_HOLD_MS;
    detector.setThresholds(restLevel + THRESH_ON_FRACTION  * span,
                           restLevel + THRESH_OFF_FRACTION * span);
    detector.active = false;
    detector.pending = false;
    detector.lastChangeMs = millis();
    Serial.printf("[cal] thresholds: close > %.1f, open < %.1f\n", detector.onThreshold, detector.offThreshold);
    Serial.println(F("[run] EMG control active"));
    startPhase(Phase::Run);
}

// ------------------------------------------------------------------------------------------
// Serial interface
// ------------------------------------------------------------------------------------------
static void handleSerial()
{
    while (Serial.available()) {
        switch (Serial.read()) {
            case 'c': startPhase(Phase::Warmup); break;
            case 'p': plotOutput = !plotOutput; break;
            case 'i': curOutput = !curOutput; break;
            case 'o': ovrMode = FORCE_OPEN;  Serial.println(F("[ovr] forced OPEN"));  break;
            case 'f': ovrMode = FORCE_CLOSE; Serial.println(F("[ovr] forced CLOSE")); break;
            case 'a': ovrMode = AUTO;        Serial.println(F("[ovr] automatic"));   break;
            case 'r': setCommand(lastCmdClosed, millis()); Serial.println(F("[stall] flags cleared, servos re-armed")); break;
            default: break;
        }
    }
}

static void printCurrents(uint32_t nowMs)
{
    if (!curOutput || nowMs - lastCurMs < 100) return;
    lastCurMs = nowMs;
    for (int i = 0; i < NUM_FINGERS; i++) {
        Serial.printf("%s%.2f", i ? "," : "I[A]: ", hand[i].amps);
    }
    Serial.print("  state: ");
    for (int i = 0; i < NUM_FINGERS; i++) {
        const char* s = !hand[i].attached ? "F" : (hand[i].stall.state == cur::State::Holding ? "H" : "N");
        Serial.print(s);
    }
    Serial.println();
}

// ------------------------------------------------------------------------------------------
// Arduino entry points
// ------------------------------------------------------------------------------------------
void setup()
{
    Serial.begin(115200);
    delay(200);
    Serial.println(F("\nNeuroHand EMG prosthesis - starting"));
    Serial.println(F("Commands: c=recalibrate p=EMG plot i=currents o/f/a=open/close/auto r=reset stall"));

    pinMode(STATUS_LED_PIN, OUTPUT);
    analogReadResolution(12);
    analogSetPinAttenuation(EMG_PIN, ADC_11db);   // 0 - ~3.3 V input range

    setupCurrentSensors();                         // zero-current calibration (servos still detached)

    for (int i = 0; i < NUM_FINGERS; i++) attachFinger(i);   // hand starts OPEN
    setCommand(false, millis());

    envelope.init(SAMPLE_RATE_HZ, DC_CUTOFF_HZ, ENVELOPE_CUTOFF_HZ);
    startPhase(Phase::Warmup);
    nextSampleUs = micros();
}

void loop()
{
    handleSerial();

    const uint32_t nowUs = micros();
    if ((int32_t)(nowUs - nextSampleUs) < 0) return;            // not yet time for the next EMG sample
    nextSampleUs += SAMPLE_PERIOD_US;
    if ((int32_t)(nowUs - nextSampleUs) > (int32_t)(5 * SAMPLE_PERIOD_US)) nextSampleUs = nowUs;  // resync if we fell behind

    const float env = envelope.update((float)analogRead(EMG_PIN));
    const uint32_t nowMs = millis();
    const uint32_t inPhase = nowMs - phaseStartMs;

    switch (phase) {
        case Phase::Warmup:
            if (inPhase >= CAL_WARMUP_MS) startPhase(Phase::CalRest);
            break;
        case Phase::CalRest:
            restSum += env; restN++;
            if (inPhase >= CAL_REST_MS) startPhase(Phase::CalFlex);
            break;
        case Phase::CalFlex:
            if (inPhase >= CAL_FLEX_LEAD_MS) { flexSum += env; flexN++; }
            if (inPhase >= CAL_FLEX_LEAD_MS + CAL_FLEX_MS) finishCalibration();
            break;
        case Phase::Run:
            detector.update(env, nowMs);
            break;
    }

    bool wantClosed = (phase == Phase::Run) && detector.active;
    if (ovrMode == FORCE_OPEN)  wantClosed = false;
    if (ovrMode == FORCE_CLOSE) wantClosed = true;
    if (wantClosed != lastCmdClosed) {
        setCommand(wantClosed, nowMs);
        Serial.println(wantClosed ? F("[cmd] CLOSE") : F("[cmd] OPEN"));
    }
    digitalWrite(STATUS_LED_PIN, wantClosed);

    if (nowMs - lastServoMs >= SERVO_UPDATE_MS) {
        lastServoMs = nowMs;
        servoTick(nowMs);
    }

    printCurrents(nowMs);

    if (plotOutput && nowMs - lastPlotMs >= 20) {
        lastPlotMs = nowMs;
        Serial.printf("%.1f,%.1f,%.1f,%d\n", env, detector.onThreshold, detector.offThreshold, wantClosed ? 100 : 0);
    }
}
