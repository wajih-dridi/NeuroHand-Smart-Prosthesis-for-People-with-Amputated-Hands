/**
 * @file    emg_processing.h
 * @brief   Hardware-independent EMG envelope extraction and hysteresis detector.
 *
 * Header-only, no Arduino dependency, so it is unit-tested on the PC (see tests/test_emg.cpp).
 *
 * Pipeline:  raw ADC  ->  remove DC (slow tracker)  ->  rectify  ->  low-pass  ->  envelope
 *            envelope ->  Schmitt-trigger (two thresholds) + minimum hold time -> active flag
 */
#pragma once
#include <math.h>
#include <stdint.h>

namespace emg {

constexpr float kPi = 3.14159265358979f;

/** First-order IIR coefficient for a given cutoff frequency. */
inline float alphaFromCutoff(float cutoffHz, float sampleRateHz)
{
    return 1.0f - expf(-2.0f * kPi * cutoffHz / sampleRateHz);
}

struct Envelope {
    float dc = 0.0f;
    float env = 0.0f;
    float dcAlpha = 0.0f;
    float envAlpha = 0.0f;
    bool  primed = false;

    void init(float sampleRateHz, float dcCutoffHz, float envCutoffHz)
    {
        dcAlpha  = alphaFromCutoff(dcCutoffHz, sampleRateHz);
        envAlpha = alphaFromCutoff(envCutoffHz, sampleRateHz);
        dc = 0.0f; env = 0.0f; primed = false;
    }

    /** Feed one raw sample, returns the current envelope (same units as the input). */
    float update(float raw)
    {
        if (!primed) { dc = raw; primed = true; }      // avoid a start-up transient
        dc  += dcAlpha * (raw - dc);
        const float rectified = fabsf(raw - dc);
        env += envAlpha * (rectified - env);
        return env;
    }
};

/**
 * Schmitt trigger with confirmation window and minimum hold time.
 *   active == "muscle contracted" == "hand closed"
 *  - confirmMs : envelope must stay beyond the threshold this long before the state flips
 *                (rejects short artefacts such as cable bumps or electrode motion)
 *  - minHoldMs : minimum time between two state changes (anti-chatter)
 */
struct Detector {
    float    onThreshold  = 1e9f;
    float    offThreshold = 1e9f;
    uint32_t confirmMs    = 200;
    uint32_t minHoldMs    = 300;
    bool     active       = false;
    uint32_t lastChangeMs = 0;
    bool     pending      = false;
    uint32_t pendingSinceMs = 0;

    void setThresholds(float on, float off) { onThreshold = on; offThreshold = off; }

    bool update(float envelope, uint32_t nowMs)
    {
        const bool wantsChange = active ? (envelope < offThreshold) : (envelope > onThreshold);

        if (!wantsChange) { pending = false; return active; }          // condition dropped: restart the window
        if (!pending)     { pending = true; pendingSinceMs = nowMs; }

        if ((uint32_t)(nowMs - pendingSinceMs) >= confirmMs &&
            (uint32_t)(nowMs - lastChangeMs)   >= minHoldMs) {
            active = !active;
            lastChangeMs = nowMs;
            pending = false;
        }
        return active;
    }
};

}  // namespace emg
