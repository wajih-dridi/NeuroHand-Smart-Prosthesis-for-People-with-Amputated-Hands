/**
 * @file    config.h
 * @brief   Hardware and tuning constants for NeuroHand. EDIT THESE to match your wiring.
 *
 * Pin choices below are a recommended ESP32 layout (ADC1 only, no strapping pins).
 * If your build uses different pins (e.g. from your Fritzing diagram), change them here only.
 */
#pragma once

// ---- EMG input --------------------------------------------------------------
#define EMG_PIN               39      // ADC1_CH3 (VN) - input-only pin. Signal MUST stay within 0-3.3 V!
#define SAMPLE_RATE_HZ        1000
#define SAMPLE_PERIOD_US      (1000000UL / SAMPLE_RATE_HZ)

// ---- Signal processing ------------------------------------------------------
#define DC_CUTOFF_HZ          0.5f    // baseline (DC offset) tracker
#define ENVELOPE_CUTOFF_HZ    4.0f    // envelope smoothing: lower = smoother but slower
#define CONFIRM_MS            200     // envelope must stay past a threshold this long (artefact rejection)
#define MIN_HOLD_MS           300     // minimum time between state changes (anti-chatter)

// ---- Calibration ------------------------------------------------------------
#define CAL_WARMUP_MS         2000    // let the DC tracker settle
#define CAL_REST_MS           3000    // relax the muscle
#define CAL_FLEX_LEAD_MS      700     // time to start flexing before measuring
#define CAL_FLEX_MS           3000    // hold a firm contraction
#define CAL_MIN_SEPARATION    15.0f   // ADC counts (12-bit); lower it if calibration keeps failing
#define THRESH_ON_FRACTION    0.40f   // close hand above rest + 40 % of (flex - rest)
#define THRESH_OFF_FRACTION   0.20f   // open hand below rest + 20 % (hysteresis)

// ---- Servos (one per finger) --------------------------------------------------
#define NUM_FINGERS           5
static const int  FINGER_PINS[NUM_FINGERS]   = {13, 14, 25, 26, 27};     // thumb, index, middle, ring, little
static const bool FINGER_INVERT[NUM_FINGERS] = {false, false, false, false, false};  // true for mirror-mounted servos
#define SERVO_MIN_US          500
#define SERVO_MAX_US          2400
#define OPEN_ANGLE            0       // = posOuverte in the prototype sketch
#define CLOSED_ANGLE          180     // = posFermee  in the prototype sketch
#define SERVO_STEP_DEG        3       // max degrees per update (slew-rate limit)
#define SERVO_UPDATE_MS       10      // servo + current-sensor update period

// ---- ACS712 current sensors (one per servo) -----------------------------------
// The ACS712 runs from 5 V and its output swings up to ~5 V: it MUST go through a divider
// before the ESP32 ADC (3.3 V max). Recommended: 10 k (to sensor) + 15 k (to GND) -> ratio 0.6.
static const int ACS_PINS[NUM_FINGERS] = {32, 33, 34, 35, 36};           // ADC1 channels
#define ACS_DIVIDER_RATIO     0.6f    // R_bottom / (R_top + R_bottom). Use 1.0 if you have no divider (not for 5 V!)
#define ACS_SENSITIVITY_V_A   0.185f  // 5 A module = 0.185 V/A, 20 A = 0.100, 30 A = 0.066
#define ACS_FILTER_ALPHA      0.20f   // current smoothing (0..1, lower = smoother)

// ---- Stall / obstacle protection ------------------------------------------------
#define STALL_CURRENT_A       0.40f   // "seuilBlocage": soft stall -> freeze finger (grip detected)
#define STALL_CONFIRM_MS      150     // current must stay above the soft threshold this long
#define STALL_BACKOFF_DEG     4       // relax the finger slightly when a stall is detected
#define HARD_CURRENT_A        1.00f   // hard overload -> detach (power off) that servo
#define HARD_CONFIRM_MS       500
#define INRUSH_IGNORE_MS      400     // ignore current spikes right after a new open/close command

#define STATUS_LED_PIN        2       // on-board LED mirrors the "hand closed" state
