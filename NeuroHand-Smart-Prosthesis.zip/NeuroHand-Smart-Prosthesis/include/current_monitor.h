/**
 * @file    current_monitor.h
 * @brief   ACS712 current conversion and per-servo stall detection (hardware independent).
 *
 * Header-only, no Arduino dependency, unit-tested on the PC (tests/test_current.cpp).
 *
 * Stall logic per finger:
 *   Normal  --(I > stallA for confirmMs, after the inrush window)-->  Holding  (object grasped / blocked)
 *   Holding/Normal --(I > hardA for hardMs)-->                       Fault    (servo must be detached)
 *   Any new open/close command (onCommand) clears Holding/Fault and restarts the inrush window.
 */
#pragma once
#include <math.h>
#include <stdint.h>

namespace cur {

struct Acs712 {
    float sensitivityVperA = 0.185f;
    float dividerRatio     = 0.6f;     // V_adc / V_sensor
    float zeroV            = 2.5f;     // sensor output at 0 A (measured at boot)
    float alpha            = 0.20f;
    float filteredA        = 0.0f;     // signed, smoothed

    /** Convert the ADC pin voltage (mV) to sensor-output volts. */
    float sensorVolts(float adcMilliVolts) const { return (adcMilliVolts / 1000.0f) / dividerRatio; }

    /** Call with the average pin voltage measured while NO current flows. */
    void calibrateZero(float avgAdcMilliVolts) { zeroV = sensorVolts(avgAdcMilliVolts); filteredA = 0.0f; }

    float amps(float adcMilliVolts) const { return (sensorVolts(adcMilliVolts) - zeroV) / sensitivityVperA; }

    /** Feed one sample, returns |current| in amps (smoothed). */
    float update(float adcMilliVolts)
    {
        filteredA += alpha * (amps(adcMilliVolts) - filteredA);
        return fabsf(filteredA);
    }
};

enum class State : uint8_t { Normal, Holding, Fault };

struct StallDetector {
    float    stallA     = 0.40f;
    float    hardA      = 1.00f;
    uint32_t confirmMs  = 150;
    uint32_t hardMs     = 500;
    uint32_t inrushMs   = 400;

    State    state      = State::Normal;
    uint32_t cmdMs      = 0;
    bool     over       = false;
    bool     hardOver   = false;
    uint32_t overSince  = 0;
    uint32_t hardSince  = 0;

    /** A new open/close command was issued: clear stall/fault and start the inrush-ignore window. */
    void onCommand(uint32_t nowMs)
    {
        state = State::Normal; cmdMs = nowMs; over = false; hardOver = false;
    }

    State update(float amps, uint32_t nowMs)
    {
        if (state == State::Fault) return state;
        if ((uint32_t)(nowMs - cmdMs) < inrushMs) { over = false; hardOver = false; return state; }

        if (amps > hardA) {
            if (!hardOver) { hardOver = true; hardSince = nowMs; }
            if ((uint32_t)(nowMs - hardSince) >= hardMs) { state = State::Fault; return state; }
        } else {
            hardOver = false;
        }

        if (state == State::Normal) {
            if (amps > stallA) {
                if (!over) { over = true; overSince = nowMs; }
                if ((uint32_t)(nowMs - overSince) >= confirmMs) state = State::Holding;
            } else {
                over = false;
            }
        }
        return state;
    }
};

}  // namespace cur
