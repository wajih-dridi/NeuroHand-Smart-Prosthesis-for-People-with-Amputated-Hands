// Bench test (ESP32 version of the prototype sketch): one servo toggles between 0 and 180 deg every 5 s
// while an ACS712 measures its current. The servo is detached if an obstacle (stall) is detected.
// Requires the ESP32Servo library. ACS712 output MUST go through a divider (e.g. 10k/15k, ratio 0.6).
#include <ESP32Servo.h>

const int SERVO_PIN = 13;
const int ACS_PIN   = 32;                    // ADC1_CH4
const float DIVIDER = 0.6f;
const float SENS    = 0.185f;                // V/A (5 A module)
const float STALL_A = 0.4f;                  // "seuilBlocage"
const unsigned long INTERVAL_MS = 5000;
const unsigned long INRUSH_MS   = 400;

Servo servo;
float zeroV = 2.5f;
int angle = 0;
bool blocked = false;
unsigned long lastToggle = 0, lastMove = 0;

float readVolts() { return (analogReadMilliVolts(ACS_PIN) / 1000.0f) / DIVIDER; }

void setup() {
  Serial.begin(115200);
  analogSetPinAttenuation(ACS_PIN, ADC_11db);
  float s = 0; for (int i = 0; i < 200; i++) { s += readVolts(); delay(1); }
  zeroV = s / 200.0f;                        // zero-current voltage, measured with the servo detached
  Serial.printf("zero = %.3f V\n", zeroV);
  servo.setPeriodHertz(50);
  servo.attach(SERVO_PIN, 500, 2400);
  servo.write(angle);
  lastToggle = lastMove = millis();
}

void loop() {
  if (blocked) return;
  float amps = fabsf((readVolts() - zeroV) / SENS);
  Serial.println(amps);

  if (millis() - lastMove > INRUSH_MS && amps > STALL_A) {   // ignore the start-up spike
    Serial.println("Obstacle detected! Servo stopped.");
    servo.detach();
    blocked = true;
    return;
  }
  if (millis() - lastToggle >= INTERVAL_MS) {
    angle = (angle == 0) ? 180 : 0;
    servo.write(angle);
    lastToggle = lastMove = millis();
  }
  delay(20);
}
