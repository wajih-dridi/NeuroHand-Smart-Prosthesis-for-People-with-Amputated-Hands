// Bench tool: stream the raw EMG signal to the Serial Plotter (same idea as your first Arduino Uno test).
// Use it to check electrode placement and the signal range BEFORE running the full firmware.
// The EMG output must stay within 0-3.3 V on the ESP32.
const int EMG_PIN = 39;          // ADC1_CH3

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);                  // 0..4095
  analogSetPinAttenuation(EMG_PIN, ADC_11db);
}

void loop() {
  Serial.println(analogRead(EMG_PIN));
  delay(2);                                  // ~500 Hz
}
