# Calibration guide

Calibration runs automatically at boot (and when you send `c` over serial):

| Step | Duration | What to do |
|------|----------|------------|
| Warm-up | 2 s | Relax; the DC-offset tracker settles |
| Rest | 3 s | Keep the muscle fully relaxed |
| Flex | 0.7 s lead + 3 s | Contract firmly and hold |

Result: `rest` and `flex` envelope levels (ADC counts) -> thresholds

```
close threshold = rest + 0.40 * (flex - rest)
open  threshold = rest + 0.20 * (flex - rest)     (lower value = hysteresis)
```
If `flex - rest` is below `CAL_MIN_SEPARATION` the calibration is rejected and repeated.

## Signal chain
raw ADC (1 kHz) -> subtract slow DC tracker (0.5 Hz) -> rectify -> low-pass (4 Hz) -> envelope  
-> Schmitt trigger with a **200 ms confirmation window** (rejects short artefacts) and a **300 ms minimum hold** (no chatter).

Expected response time: ~200-250 ms from contraction to servo motion (verified in the host test with synthetic data;
measure your own latency on the real hardware).

## Tuning knobs (`include/config.h`)
| Parameter | Effect |
|-----------|--------|
| `ENVELOPE_CUTOFF_HZ` | Lower = smoother, slower |
| `CONFIRM_MS` | Higher = fewer false triggers, more latency |
| `THRESH_ON_FRACTION` / `THRESH_OFF_FRACTION` | Sensitivity / hysteresis width |
| `SERVO_STEP_DEG` | Finger closing speed |

## Visualising
Send `p` to stream `env,on_threshold,off_threshold,state` and open a serial plotter (PlatformIO: *Monitor* with
a plotting extension, or Arduino IDE *Serial Plotter*). Screenshot it for your `images/` folder.

## Current-sensor (ACS712) setup
Servo power must be **on** at boot: the firmware averages each sensor for 200 ms while the servos are still detached
and stores that as the 0 A reference. The log shows `zero = x.xxx V` per finger; it should be close to 2.5 V.
Send `i` to stream the five currents (`I[A]: ...`) and the per-finger state (`N` normal, `H` holding, `F` fault),
then tune `STALL_CURRENT_A`, `HARD_CURRENT_A` and `STALL_CONFIRM_MS` in `config.h` against your servos
(free motion vs. a blocked finger).

## Troubleshooting
| Problem | Likely cause |
|---------|--------------|
| "FAILED: contraction not distinguishable" | Poor electrode contact, wrong placement, sensor gain too low |
| Triggers at rest | Mains/motion noise; shorten cables, battery power, raise `THRESH_ON_FRACTION` |
| Servos jitter | Shared supply/brownout, add capacitor, separate supply |
| Stall triggers during normal motion | Raise `STALL_CURRENT_A` or `INRUSH_IGNORE_MS`; check the supply is not sagging |
| `zero` far from 2.5 V in the log | ACS712 not on 5 V, divider missing/wrong, or servo wiring through the sensor is reversed |
| Finger stops early when gripping | Intended: stall detected (object grasped). Lower sensitivity by raising the threshold |
| Hand never opens | `THRESH_OFF_FRACTION` too close to the contraction level or muscle fatigue; recalibrate |
