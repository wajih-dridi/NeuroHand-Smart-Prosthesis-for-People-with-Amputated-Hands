# Safety

NeuroHand is an **educational prototype and not a medical device**. It has not been clinically evaluated.

- Power the EMG front-end and ESP32 from a **battery** or an isolated USB supply when electrodes are on your body.
  Do not connect electrodes to equipment that is also connected to mains-powered devices.
- Do not place electrodes across the chest, on the head/neck, or on broken or irritated skin.
- Stop immediately if you feel discomfort, tingling or skin irritation.
- Servos and linkages can pinch: keep fingers clear while testing and use the serial override (`o`) to open the hand.
- Test the mechanism on the bench (no person wearing it) before any wearable test.
- **Current sensing is a protection aid, not a safety guarantee.** Keep a fuse or current-limited supply on the servo rail
  and a physical power switch.
- **ESP32 inputs are 3.3 V only.** An unlimited 5 V ACS712 output or an EMG output above 3.3 V can destroy the pin.
