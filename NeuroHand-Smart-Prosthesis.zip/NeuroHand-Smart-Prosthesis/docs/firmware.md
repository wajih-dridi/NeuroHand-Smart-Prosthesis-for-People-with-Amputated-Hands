# Firmware overview

## Modules
| File | Purpose | Hardware dependent? |
|------|---------|--------------------|
| `include/emg_processing.h` | DC removal, rectification, envelope, hysteresis detector with confirmation + hold | No (host-tested) |
| `include/current_monitor.h` | ACS712 conversion, zero calibration, filter, per-finger stall state machine | No (host-tested) |
| `include/config.h` | Pins and tuning constants | - |
| `src/main.cpp` | Calibration state machine, servo control, serial interface | Yes (ESP32 / Arduino) |

## Control loop
- **1 kHz:** read EMG -> envelope -> detector (open/close decision).
- **100 Hz (`SERVO_UPDATE_MS`):** read the 5 ACS712 -> update stall state -> slew-limit and write the 5 servos.

## Stall state machine (per finger)
```
Normal --(I > STALL_CURRENT_A for STALL_CONFIRM_MS)--> Holding   (freeze + back off STALL_BACKOFF_DEG)
Any    --(I > HARD_CURRENT_A  for HARD_CONFIRM_MS )--> Fault     (servo detached)
new command or 'r' --------------------------------->  Normal    (re-attached)
```
The first `INRUSH_IGNORE_MS` after every command is ignored because servos draw a start-up current spike.

## From the prototype sketch to the final firmware
| Prototype (Arduino Uno sketch) | Final firmware |
|--------------------------------|----------------|
| `pinsServos[5] = {3,5,6,9,10}` | `FINGER_PINS` (ESP32 GPIOs) |
| `pinsACS[5] = {A0..A4}` | `ACS_PINS` (ADC1 pins, via dividers) |
| `seuilBlocage = 0.3` A | `STALL_CURRENT_A` (+ confirmation time and inrush window) |
| `courant = (raw - 512) * 5/1023 / 0.185` | `cur::Acs712` (mV, divider ratio, measured zero) |
| `valeurEMG > seuilEMG` | envelope + calibrated thresholds + hysteresis |
| `fermerBras()` / `ouvrirBras()` | `setCommand(true/false)` + slew-limited motion |
| `posFermee` / `posOuverte` | `CLOSED_ANGLE` / `OPEN_ANGLE` |
| `servos[i].detach()` on block | Holding (freeze) first, detach only on hard overload |
| `delay(100)` polling loop | Non-blocking 1 kHz / 100 Hz loops |
| EEPROM last-angle toggle (bench test) | Replaced by `examples/servo_current_test` |

## Extending
- **Several hand gestures:** use 2 EMG channels (flexors/extensors) and map combinations to finger groups.
- **Per-finger force limit:** use each finger's measured current as a grip-force estimate.
- **Wireless telemetry:** add BLE/Wi-Fi once the ADC1 pins are confirmed free.
