# Hardware and wiring

## Bill of materials
| Qty | Part | Notes |
|-----|------|-------|
| 1 | ESP32 DevKit (ESP32-WROOM-32) | Pins in `config.h` assume ADC1 pins 32-36, 39 are free |
| 1 | EMG sensor board + 3-lead cable | Analog output; check its supply and output range (see below) |
| 3 | Surface (ECG-type, snap) electrodes | Two measuring + one reference |
| 5 | Hobby servos | One per finger |
| 5 | ACS712 5 A modules | One per servo; 185 mV/A |
| 10 | Resistors 10 k and 15 k (x5 each) | Divider for every ACS712 output |
| 1 | EMG output limiter | Divider or clamp so the EMG signal never exceeds 3.3 V |
| 1 | Servo power source | 5-6 V, **>= 3 A peak** (buck converter from a 2S Li-ion/LiPo pack is typical) |
| 1 | 470-1000 uF capacitor | Across the servo supply |
| 1 | Battery supply for the EMG board | Keeps the body-connected side isolated from mains |
| 1 | 3D-printed hand + socket | See CAD renders in the README |

## Pin map (`include/config.h`)
```
EMG output        -> GPIO39  (ADC1_CH3, input only)      via limiter, max 3.3 V
Servo signals     -> GPIO13, 14, 25, 26, 27              thumb, index, middle, ring, little
ACS712 outputs    -> GPIO32, 33, 34, 35, 36  (ADC1)      each through a 10k/15k divider
Status LED        -> GPIO2 (on-board)
```
Use **ADC1** pins only. These are fine with Wi-Fi/Bluetooth off, and the code does not use them. If your own wiring
uses other pins (e.g. from your Fritzing diagram), edit `FINGER_PINS`, `ACS_PINS` and `EMG_PIN`.

## ACS712 on a 3.3 V ESP32 (important)
The ACS712 is powered from 5 V and outputs ~2.5 V at 0 A, swinging 185 mV per amp. The ESP32 ADC only tolerates
**3.3 V**, and the 12-bit ADC differs from the Arduino Uno's 10-bit/5 V, so the prototype formula
`(raw - 512) * 5/1023 / 0.185` cannot be reused unchanged.

```
ACS712 OUT --[ 10 k ]--+--[ 15 k ]-- GND          ratio = 15/(10+15) = 0.6
                       |
                       +--> ESP32 ADC pin         2.5 V -> 1.5 V at rest, 5 V -> 3.0 V max
```
The firmware reads millivolts at the pin, divides by `ACS_DIVIDER_RATIO`, and **measures the zero-current voltage at
boot** (servos detached), so sensor offset errors are compensated automatically. If you use a 20 A / 30 A module set
`ACS_SENSITIVITY_V_A` to 0.100 / 0.066.

Note: the 5 A module has limited resolution for small servos (~0.1 A noise). The thresholds (`STALL_CURRENT_A`, etc.)
are starting values; tune them against your own servos.

## EMG board output range (important)
Many analog EMG boards have an output that can reach their supply voltage. Check your board's datasheet, measure the
output on a multimeter/oscilloscope with a strong contraction, and add a divider or clamp if it can exceed 3.3 V.
Your first test (Arduino Uno, 5 V ADC) tolerated a wider range than the ESP32 does.

## Power
- Servos: dedicated supply, common ground with the ESP32. A linear regulator such as a 7805 (about 1 A) cannot feed five
  servos under load, and 9 V alkaline batteries cannot deliver servo stall currents. Use a buck converter rated >= 3 A
  and a suitable battery pack.
- EMG board: if it needs a dual (+/-) supply, a pair of 9 V batteries is a good, isolated choice.
- Add a bulk capacitor on the servo supply; keep analog wires away from servo wires.

## Electrode placement (forearm)
1. Two measuring electrodes along the muscle belly (~2-3 cm apart, along the fibre direction).
2. Reference electrode on an electrically quiet, bony area (elbow or wrist bone).
3. Clean/dry the skin, use fresh electrodes, and fix the cables so they do not pull on the pads.
