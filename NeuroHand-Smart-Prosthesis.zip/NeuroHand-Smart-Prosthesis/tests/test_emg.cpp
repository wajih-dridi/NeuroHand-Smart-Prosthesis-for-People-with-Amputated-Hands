// Host-side verification of the EMG pipeline with a synthetic signal.  Run: make test
#include <cstdio>
#include <cstdint>
#include "emg_processing.h"

static uint32_t lcg = 12345;
static float noise()  // deterministic uniform noise in [-1, 1]
{
    lcg = lcg * 1664525u + 1013904223u;
    return ((lcg >> 8) & 0xFFFF) / 32767.5f - 1.0f;
}

static int failures = 0;
#define CHECK(cond, msg) do { if (cond) std::printf("PASS: %s\n", msg); \
                              else { std::printf("FAIL: %s\n", msg); failures++; } } while (0)

int main()
{
    const float fs = 1000.0f;
    emg::Envelope env;  env.init(fs, 0.5f, 4.0f);
    emg::Detector det;  det.minHoldMs = 300;  det.confirmMs = 200;

    // Synthetic ADC: DC offset 2000 counts, rest noise +-8, contraction burst noise +-200.
    auto sample = [&](float amp) { return 2000.0f + amp * noise(); };

    // 1) Rest 3 s
    float restAvg = 0; int n = 0;
    for (int i = 0; i < 3000; i++) { float e = env.update(sample(8)); if (i > 1000) { restAvg += e; n++; } }
    restAvg /= n;

    // 2) Flex 3 s
    float flexAvg = 0; n = 0;
    for (int i = 0; i < 3000; i++) { float e = env.update(sample(200)); if (i > 700) { flexAvg += e; n++; } }
    flexAvg /= n;

    std::printf("rest envelope = %.2f, flex envelope = %.2f\n", restAvg, flexAvg);
    CHECK(restAvg < 10.0f,                 "DC offset removed: rest envelope small despite 2000-count offset");
    CHECK(flexAvg > 10.0f * restAvg,       "contraction envelope >> rest envelope");

    const float span = flexAvg - restAvg;
    det.setThresholds(restAvg + 0.40f * span, restAvg + 0.20f * span);

    // 3) Replay rest / flex / rest and count state changes
    uint32_t t = 0; int transitions = 0; bool last = false;
    bool closedDuringFlex = false, openAfterRelax = false;
    auto run = [&](float amp, int ms, bool* flag, bool expectActive) {
        for (int i = 0; i < ms; i++, t++) {
            bool a = det.update(env.update(sample(amp)), t);
            if (a != last) { transitions++; last = a; }
            if (flag && i > ms - 100 && a == expectActive) *flag = true;
        }
    };
    run(8,   1500, nullptr, false);
    run(200, 2000, &closedDuringFlex, true);
    run(8,   2000, &openAfterRelax, false);

    CHECK(closedDuringFlex,   "detector closes the hand during contraction");
    CHECK(openAfterRelax,     "detector re-opens the hand after relaxation");
    CHECK(transitions == 2,   "exactly one close and one open (no chatter)");

    // 4) Hold time: brief 100 ms spike must not toggle
    det.active = false; det.lastChangeMs = t;
    for (int i = 0; i < 1000; i++, t++) det.update(env.update(sample(8)), t);
    int before = 0; bool prev = det.active;
    for (int i = 0; i < 100; i++, t++) { bool a = det.update(env.update(sample(200)), t); if (a != prev) { before++; prev = a; } }
    for (int i = 0; i < 1000; i++, t++) { bool a = det.update(env.update(sample(8)), t);   if (a != prev) { before++; prev = a; } }
    CHECK(before == 0, "100 ms artefact is rejected by confirmation window");

    // 5) Detection latency of a genuine contraction stays reasonable
    int latency = -1;
    for (int i = 0; i < 1000; i++, t++) {
        bool a = det.update(env.update(sample(200)), t);
        if (a && latency < 0) latency = i;
    }
    std::printf("detection latency = %d ms\n", latency);
    CHECK(latency > 0 && latency < 500, "genuine contraction detected within 500 ms");

    if (failures) { std::printf("%d TEST(S) FAILED\n", failures); return 1; }
    std::printf("ALL EMG TESTS PASSED\n");
    return 0;
}
