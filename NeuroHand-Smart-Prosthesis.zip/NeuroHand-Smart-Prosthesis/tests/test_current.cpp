// Host-side verification of ACS712 conversion and stall detection.  Run: make test
#include <cstdio>
#include <cmath>
#include "current_monitor.h"

static int failures = 0;
#define CHECK(cond, msg) do { if (cond) std::printf("PASS: %s\n", msg); \
                              else { std::printf("FAIL: %s\n", msg); failures++; } } while (0)

// ADC pin millivolts the ESP32 would see for a given current (ratio 0.6, zero 2.5 V, 0.185 V/A)
static float pinMv(float amps, float zeroV = 2.5f) { return (zeroV + 0.185f * amps) * 0.6f * 1000.0f; }

int main()
{
    cur::Acs712 acs; acs.sensitivityVperA = 0.185f; acs.dividerRatio = 0.6f;

    // 1) zero calibration absorbs an offset error (sensor really sits at 2.46 V)
    acs.calibrateZero(pinMv(0.0f, 2.46f));
    CHECK(std::fabs(acs.amps(pinMv(0.0f, 2.46f))) < 0.001f, "zero-current reads 0 A after calibration");
    CHECK(std::fabs(acs.amps(pinMv(1.0f, 2.46f)) - 1.0f) < 0.01f, "1.0 A converts correctly (185 mV/A, divider 0.6)");
    CHECK(pinMv(5.0f) < 3300.0f, "divider keeps a +5 A reading below 3.3 V at the ADC pin");

    // 2) stall detector with simulated timeline (1 ms steps)
    cur::StallDetector sd; sd.stallA = 0.4f; sd.hardA = 1.0f;
    uint32_t t = 0; sd.onCommand(t);

    // inrush: 0.9 A for 300 ms right after the command must be ignored
    for (; t < 300; t++) sd.update(0.9f, t);
    CHECK(sd.state == cur::State::Normal, "inrush spike right after a command is ignored");

    // normal moving current 0.2 A
    for (; t < 800; t++) sd.update(0.2f, t);
    CHECK(sd.state == cur::State::Normal, "normal running current does not trigger");

    // brief 80 ms spike (< confirm window)
    for (int i = 0; i < 80; i++, t++) sd.update(0.6f, t);
    for (int i = 0; i < 200; i++, t++) sd.update(0.2f, t);
    CHECK(sd.state == cur::State::Normal, "short spike shorter than the confirm window is ignored");

    // sustained 0.6 A -> Holding (grip detected)
    for (int i = 0; i < 300; i++, t++) sd.update(0.6f, t);
    CHECK(sd.state == cur::State::Holding, "sustained over-current -> Holding (stall/grip)");

    // sustained 1.5 A -> Fault
    for (int i = 0; i < 700; i++, t++) sd.update(1.5f, t);
    CHECK(sd.state == cur::State::Fault, "sustained hard overload -> Fault (detach)");
    sd.update(0.0f, t++);
    CHECK(sd.state == cur::State::Fault, "Fault latches until a new command");

    // new command clears it
    sd.onCommand(t);
    CHECK(sd.state == cur::State::Normal, "new command clears Fault");

    // 3) smoothing: single noisy sample cannot trip the filter
    cur::Acs712 f; f.calibrateZero(pinMv(0.0f));
    float peak = 0; for (int i = 0; i < 50; i++) peak = std::fmax(peak, f.update(pinMv(0.0f)));
    float spike = f.update(pinMv(2.0f));
    CHECK(spike < 0.5f, "one 2 A noise sample is attenuated by the filter");
    (void)peak;

    if (failures) { std::printf("%d TEST(S) FAILED\n", failures); return 1; }
    std::printf("ALL CURRENT-MONITOR TESTS PASSED\n");
    return 0;
}
